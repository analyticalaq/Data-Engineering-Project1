# Databricks notebook source
configs = {
  "fs.azure.account.auth.type": "CustomAccessToken",
  "fs.azure.account.custom.token.provider.class": spark.conf.get("spark.databricks.passthrough.adls.gen2.tokenProviderClassName")
}

# Optionally, you can add  to the source URI of your mount point.
dbutils.fs.mount(
  source = "abfss://rawdatabronze@datalakegen2storage1.dfs.core.windows.net/",
  mount_point = "/mnt/rawdatabronze",
  extra_configs = configs)

# COMMAND ----------

dbutils.fs.ls("/mnt/rawdatabronze/SalesLT/")

# COMMAND ----------

configs = {
  "fs.azure.account.auth.type": "CustomAccessToken",
  "fs.azure.account.custom.token.provider.class": spark.conf.get("spark.databricks.passthrough.adls.gen2.tokenProviderClassName")
}

# Optionally, you can add  to the source URI of your mount point.
dbutils.fs.mount(
  source = "abfss://silverdata@datalakegen2storage1.dfs.core.windows.net/",
  mount_point = "/mnt/silverdata",
  extra_configs = configs)

# COMMAND ----------

configs = {
  "fs.azure.account.auth.type": "CustomAccessToken",
  "fs.azure.account.custom.token.provider.class": spark.conf.get("spark.databricks.passthrough.adls.gen2.tokenProviderClassName")
}

# Optionally, you can add  to the source URI of your mount point.
dbutils.fs.mount(
  source = "abfss://golddata@datalakegen2storage1.dfs.core.windows.net/",
  mount_point = "/mnt/golddata",
  extra_configs = configs)

# COMMAND ----------

